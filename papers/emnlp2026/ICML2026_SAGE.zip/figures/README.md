Place figures for the paper in this directory.

Suggested filenames (replace as you see fit):
- pipeline.pdf/png: High-level method diagram for \method{}
- results_main.pdf/png: Headline results plot/table
- annealing_study.pdf/png: Temperature annealing ablation
- benchmarks_table.pdf/png: Aggregated benchmark table

Overleaf will compile without these files because the LaTeX uses framed placeholders.
Swap the placeholders with \includegraphics references to these assets when ready.


